/**
 */
package roqme.metamodel.datatypes;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Single Value</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roqme.metamodel.datatypes.DatatypesPackage#getSingleValue()
 * @model abstract="true"
 * @generated
 */
public interface SingleValue extends TypedValue {
} // SingleValue
