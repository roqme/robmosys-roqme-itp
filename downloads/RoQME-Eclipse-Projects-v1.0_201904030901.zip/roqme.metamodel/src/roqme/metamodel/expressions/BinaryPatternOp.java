/**
 */
package roqme.metamodel.expressions;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Binary Pattern Op</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roqme.metamodel.expressions.ExpressionsPackage#getBinaryPatternOp()
 * @model abstract="true"
 * @generated
 */
public interface BinaryPatternOp extends BinaryTermOp {
} // BinaryPatternOp
