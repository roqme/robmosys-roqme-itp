/**
 */
package roqme.metamodel.expressions;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Term</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roqme.metamodel.expressions.ExpressionsPackage#getTerm()
 * @model abstract="true"
 * @generated
 */
public interface Term extends EObject {
} // Term
