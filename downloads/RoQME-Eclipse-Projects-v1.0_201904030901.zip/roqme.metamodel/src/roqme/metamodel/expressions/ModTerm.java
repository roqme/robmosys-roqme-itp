/**
 */
package roqme.metamodel.expressions;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Mod Term</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roqme.metamodel.expressions.ExpressionsPackage#getModTerm()
 * @model
 * @generated
 */
public interface ModTerm extends BinaryArithOp {
} // ModTerm
