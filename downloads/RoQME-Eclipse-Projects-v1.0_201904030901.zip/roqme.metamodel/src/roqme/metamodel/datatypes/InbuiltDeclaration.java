/**
 */
package roqme.metamodel.datatypes;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Inbuilt Declaration</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roqme.metamodel.datatypes.DatatypesPackage#getInbuiltDeclaration()
 * @model
 * @generated
 */
public interface InbuiltDeclaration extends DataTypeDeclaration {
} // InbuiltDeclaration
