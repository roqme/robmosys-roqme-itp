/**
 */
package roqme.metamodel.datatypes;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Data Type Declaration</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roqme.metamodel.datatypes.DatatypesPackage#getDataTypeDeclaration()
 * @model abstract="true"
 * @generated
 */
public interface DataTypeDeclaration extends EObject {
} // DataTypeDeclaration
