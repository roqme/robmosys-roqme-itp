/**
 */
package roqme.metamodel.kernel;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Primitive Context</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roqme.metamodel.kernel.KernelPackage#getPrimitiveContext()
 * @model
 * @generated
 */
public interface PrimitiveContext extends Context {
} // PrimitiveContext
