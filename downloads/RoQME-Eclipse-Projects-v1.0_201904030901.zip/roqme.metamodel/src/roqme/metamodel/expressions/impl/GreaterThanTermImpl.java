/**
 */
package roqme.metamodel.expressions.impl;

import org.eclipse.emf.ecore.EClass;

import roqme.metamodel.expressions.ExpressionsPackage;
import roqme.metamodel.expressions.GreaterThanTerm;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Greater Than Term</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class GreaterThanTermImpl extends BinaryRelationalOpImpl implements GreaterThanTerm {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected GreaterThanTermImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ExpressionsPackage.Literals.GREATER_THAN_TERM;
	}

} //GreaterThanTermImpl
