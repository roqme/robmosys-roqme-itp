/**
 */
package roqme.metamodel.expressions;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Binary Logical Op</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roqme.metamodel.expressions.ExpressionsPackage#getBinaryLogicalOp()
 * @model abstract="true"
 * @generated
 */
public interface BinaryLogicalOp extends BinaryTermOp {
} // BinaryLogicalOp
