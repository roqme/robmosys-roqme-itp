/**
 */
package roqme.metamodel.expressions;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Equal Term</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roqme.metamodel.expressions.ExpressionsPackage#getEqualTerm()
 * @model
 * @generated
 */
public interface EqualTerm extends BinaryRelationalOp {
} // EqualTerm
