/**
 */
package roqme.metamodel.datatypes;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Typed Value</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roqme.metamodel.datatypes.DatatypesPackage#getTypedValue()
 * @model abstract="true"
 * @generated
 */
public interface TypedValue extends EObject {
} // TypedValue
