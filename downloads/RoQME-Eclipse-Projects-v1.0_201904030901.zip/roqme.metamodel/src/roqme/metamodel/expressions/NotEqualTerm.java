/**
 */
package roqme.metamodel.expressions;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Not Equal Term</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roqme.metamodel.expressions.ExpressionsPackage#getNotEqualTerm()
 * @model
 * @generated
 */
public interface NotEqualTerm extends BinaryRelationalOp {
} // NotEqualTerm
