$MPC_ROOT/mwc.pl -type make -include ./mpc/  -value_template cxx=g++ -value_template GENFLAGS="-std=c++11" 
