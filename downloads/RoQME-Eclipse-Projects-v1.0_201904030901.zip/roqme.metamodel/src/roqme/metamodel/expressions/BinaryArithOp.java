/**
 */
package roqme.metamodel.expressions;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Binary Arith Op</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roqme.metamodel.expressions.ExpressionsPackage#getBinaryArithOp()
 * @model abstract="true"
 * @generated
 */
public interface BinaryArithOp extends BinaryTermOp {
} // BinaryArithOp
