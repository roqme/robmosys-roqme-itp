/**
 */
package roqme.metamodel.expressions.impl;

import org.eclipse.emf.ecore.EClass;

import roqme.metamodel.expressions.ExpressionsPackage;
import roqme.metamodel.expressions.NotEventTerm;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Not Event Term</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class NotEventTermImpl extends UnaryPatternOpImpl implements NotEventTerm {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected NotEventTermImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ExpressionsPackage.Literals.NOT_EVENT_TERM;
	}

} //NotEventTermImpl
