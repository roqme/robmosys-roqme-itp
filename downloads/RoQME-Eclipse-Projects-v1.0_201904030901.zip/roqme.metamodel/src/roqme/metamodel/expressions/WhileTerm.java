/**
 */
package roqme.metamodel.expressions;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>While Term</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roqme.metamodel.expressions.ExpressionsPackage#getWhileTerm()
 * @model
 * @generated
 */
public interface WhileTerm extends BinaryPatternOp {
} // WhileTerm
