/**
 */
package roqme.metamodel.expressions;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Div Term</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roqme.metamodel.expressions.ExpressionsPackage#getDivTerm()
 * @model
 * @generated
 */
public interface DivTerm extends BinaryArithOp {
} // DivTerm
