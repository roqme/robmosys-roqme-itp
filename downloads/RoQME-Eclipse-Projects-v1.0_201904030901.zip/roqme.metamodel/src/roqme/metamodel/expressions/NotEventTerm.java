/**
 */
package roqme.metamodel.expressions;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Not Event Term</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roqme.metamodel.expressions.ExpressionsPackage#getNotEventTerm()
 * @model
 * @generated
 */
public interface NotEventTerm extends UnaryPatternOp {
} // NotEventTerm
