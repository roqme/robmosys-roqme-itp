/**
 */
package roqme.metamodel.expressions;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Mult Term</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roqme.metamodel.expressions.ExpressionsPackage#getMultTerm()
 * @model
 * @generated
 */
public interface MultTerm extends BinaryArithOp {
} // MultTerm
