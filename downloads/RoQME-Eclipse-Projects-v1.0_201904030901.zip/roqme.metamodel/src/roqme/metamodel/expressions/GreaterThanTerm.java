/**
 */
package roqme.metamodel.expressions;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Greater Than Term</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roqme.metamodel.expressions.ExpressionsPackage#getGreaterThanTerm()
 * @model
 * @generated
 */
public interface GreaterThanTerm extends BinaryRelationalOp {
} // GreaterThanTerm
