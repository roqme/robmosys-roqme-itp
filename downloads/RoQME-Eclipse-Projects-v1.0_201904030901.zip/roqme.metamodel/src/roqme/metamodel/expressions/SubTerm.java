/**
 */
package roqme.metamodel.expressions;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sub Term</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roqme.metamodel.expressions.ExpressionsPackage#getSubTerm()
 * @model
 * @generated
 */
public interface SubTerm extends BinaryArithOp {
} // SubTerm
