$MPC_ROOT/mwc.pl -type make -value_template cxx=g++ -value_template GENFLAGS="-std=c++11" 
