/**
 */
package roqme.metamodel.expressions.impl;

import org.eclipse.emf.ecore.EClass;

import roqme.metamodel.expressions.ExpressionsPackage;
import roqme.metamodel.expressions.LessEqualTerm;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Less Equal Term</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class LessEqualTermImpl extends BinaryRelationalOpImpl implements LessEqualTerm {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LessEqualTermImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ExpressionsPackage.Literals.LESS_EQUAL_TERM;
	}

} //LessEqualTermImpl
