/**
 */
package roqme.metamodel.kernel;

import roqme.metamodel.datatypes.TypedVariable;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Context</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roqme.metamodel.kernel.KernelPackage#getContext()
 * @model abstract="true"
 * @generated
 */
public interface Context extends TypedVariable {
} // Context
