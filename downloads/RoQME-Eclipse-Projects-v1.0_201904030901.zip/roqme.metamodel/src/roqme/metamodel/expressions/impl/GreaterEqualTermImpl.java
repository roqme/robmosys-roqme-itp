/**
 */
package roqme.metamodel.expressions.impl;

import org.eclipse.emf.ecore.EClass;

import roqme.metamodel.expressions.ExpressionsPackage;
import roqme.metamodel.expressions.GreaterEqualTerm;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Greater Equal Term</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class GreaterEqualTermImpl extends BinaryRelationalOpImpl implements GreaterEqualTerm {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected GreaterEqualTermImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ExpressionsPackage.Literals.GREATER_EQUAL_TERM;
	}

} //GreaterEqualTermImpl
