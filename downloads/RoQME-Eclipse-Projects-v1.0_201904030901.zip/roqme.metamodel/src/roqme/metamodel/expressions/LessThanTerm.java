/**
 */
package roqme.metamodel.expressions;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Less Than Term</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roqme.metamodel.expressions.ExpressionsPackage#getLessThanTerm()
 * @model
 * @generated
 */
public interface LessThanTerm extends BinaryRelationalOp {
} // LessThanTerm
