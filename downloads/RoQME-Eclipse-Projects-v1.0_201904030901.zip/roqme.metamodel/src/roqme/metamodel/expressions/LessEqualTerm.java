/**
 */
package roqme.metamodel.expressions;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Less Equal Term</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roqme.metamodel.expressions.ExpressionsPackage#getLessEqualTerm()
 * @model
 * @generated
 */
public interface LessEqualTerm extends BinaryRelationalOp {
} // LessEqualTerm
