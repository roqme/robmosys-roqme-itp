/**
 */
package roqme.metamodel.expressions;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Add Term</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roqme.metamodel.expressions.ExpressionsPackage#getAddTerm()
 * @model
 * @generated
 */
public interface AddTerm extends BinaryArithOp {
} // AddTerm
