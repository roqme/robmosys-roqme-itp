/**
 */
package roqme.metamodel.expressions;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Not Boolean Term</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roqme.metamodel.expressions.ExpressionsPackage#getNotBooleanTerm()
 * @model
 * @generated
 */
public interface NotBooleanTerm extends UnaryLogicalOp {
} // NotBooleanTerm
