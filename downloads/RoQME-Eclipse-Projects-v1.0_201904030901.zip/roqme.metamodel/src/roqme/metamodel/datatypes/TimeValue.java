/**
 */
package roqme.metamodel.datatypes;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Time Value</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roqme.metamodel.datatypes.DatatypesPackage#getTimeValue()
 * @model
 * @generated
 */
public interface TimeValue extends UnitMeasuredValue {
} // TimeValue
