/**
 */
package roqme.metamodel.kernel;

import roqme.metamodel.datatypes.TypedVariable;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Parameter</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roqme.metamodel.kernel.KernelPackage#getParameter()
 * @model
 * @generated
 */
public interface Parameter extends TypedVariable {
} // Parameter
