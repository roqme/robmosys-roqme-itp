/**
 */
package roqme.metamodel.expressions;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Or Boolean Term</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roqme.metamodel.expressions.ExpressionsPackage#getOrBooleanTerm()
 * @model
 * @generated
 */
public interface OrBooleanTerm extends BinaryLogicalOp {
} // OrBooleanTerm
