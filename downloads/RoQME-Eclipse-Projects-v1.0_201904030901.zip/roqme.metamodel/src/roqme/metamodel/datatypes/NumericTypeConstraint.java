/**
 */
package roqme.metamodel.datatypes;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Numeric Type Constraint</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roqme.metamodel.datatypes.DatatypesPackage#getNumericTypeConstraint()
 * @model abstract="true"
 * @generated
 */
public interface NumericTypeConstraint extends EObject {
} // NumericTypeConstraint
