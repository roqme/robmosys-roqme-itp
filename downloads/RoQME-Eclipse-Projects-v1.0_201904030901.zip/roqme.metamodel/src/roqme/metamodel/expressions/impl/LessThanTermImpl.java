/**
 */
package roqme.metamodel.expressions.impl;

import org.eclipse.emf.ecore.EClass;

import roqme.metamodel.expressions.ExpressionsPackage;
import roqme.metamodel.expressions.LessThanTerm;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Less Than Term</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class LessThanTermImpl extends BinaryRelationalOpImpl implements LessThanTerm {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LessThanTermImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ExpressionsPackage.Literals.LESS_THAN_TERM;
	}

} //LessThanTermImpl
