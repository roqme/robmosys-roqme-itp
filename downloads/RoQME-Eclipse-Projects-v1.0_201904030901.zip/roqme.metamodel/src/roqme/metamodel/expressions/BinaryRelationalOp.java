/**
 */
package roqme.metamodel.expressions;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Binary Relational Op</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roqme.metamodel.expressions.ExpressionsPackage#getBinaryRelationalOp()
 * @model abstract="true"
 * @generated
 */
public interface BinaryRelationalOp extends BinaryTermOp {
} // BinaryRelationalOp
