/**
 */
package roqme.metamodel.expressions;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Once Term</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roqme.metamodel.expressions.ExpressionsPackage#getOnceTerm()
 * @model
 * @generated
 */
public interface OnceTerm extends UnaryPatternOp {
} // OnceTerm
