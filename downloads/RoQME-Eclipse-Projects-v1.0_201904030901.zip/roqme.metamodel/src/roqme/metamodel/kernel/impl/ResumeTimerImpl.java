/**
 */
package roqme.metamodel.kernel.impl;

import org.eclipse.emf.ecore.EClass;

import roqme.metamodel.kernel.KernelPackage;
import roqme.metamodel.kernel.ResumeTimer;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Resume Timer</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ResumeTimerImpl extends TimerActionImpl implements ResumeTimer {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ResumeTimerImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return KernelPackage.Literals.RESUME_TIMER;
	}

} //ResumeTimerImpl
