/**
 */
package roqme.metamodel.expressions;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>And Event Term</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roqme.metamodel.expressions.ExpressionsPackage#getAndEventTerm()
 * @model
 * @generated
 */
public interface AndEventTerm extends BinaryPatternOp {
} // AndEventTerm
