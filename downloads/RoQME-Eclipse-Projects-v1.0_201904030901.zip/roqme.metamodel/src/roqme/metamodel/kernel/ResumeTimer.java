/**
 */
package roqme.metamodel.kernel;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Resume Timer</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roqme.metamodel.kernel.KernelPackage#getResumeTimer()
 * @model
 * @generated
 */
public interface ResumeTimer extends TimerAction {
} // ResumeTimer
