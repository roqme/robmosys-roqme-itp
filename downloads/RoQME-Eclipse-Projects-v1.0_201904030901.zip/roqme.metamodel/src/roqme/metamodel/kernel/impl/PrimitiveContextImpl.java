/**
 */
package roqme.metamodel.kernel.impl;

import org.eclipse.emf.ecore.EClass;

import roqme.metamodel.kernel.KernelPackage;
import roqme.metamodel.kernel.PrimitiveContext;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Primitive Context</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class PrimitiveContextImpl extends ContextImpl implements PrimitiveContext {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PrimitiveContextImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return KernelPackage.Literals.PRIMITIVE_CONTEXT;
	}

} //PrimitiveContextImpl
