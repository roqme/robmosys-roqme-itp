/**
 */
package roqme.metamodel.expressions.impl;

import org.eclipse.emf.ecore.EClass;

import roqme.metamodel.expressions.ExpressionsPackage;
import roqme.metamodel.expressions.ModTerm;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Mod Term</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ModTermImpl extends BinaryArithOpImpl implements ModTerm {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ModTermImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ExpressionsPackage.Literals.MOD_TERM;
	}

} //ModTermImpl
