/**
 */
package roqme.metamodel.mapping.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import roqme.metamodel.mapping.ConfigOpt;
import roqme.metamodel.mapping.MappingPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Config Opt</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class ConfigOptImpl extends MinimalEObjectImpl.Container implements ConfigOpt {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ConfigOptImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MappingPackage.Literals.CONFIG_OPT;
	}

} //ConfigOptImpl
