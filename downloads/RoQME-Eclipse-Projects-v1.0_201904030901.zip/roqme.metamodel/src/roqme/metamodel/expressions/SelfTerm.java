/**
 */
package roqme.metamodel.expressions;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Self Term</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roqme.metamodel.expressions.ExpressionsPackage#getSelfTerm()
 * @model
 * @generated
 */
public interface SelfTerm extends Term {
} // SelfTerm
