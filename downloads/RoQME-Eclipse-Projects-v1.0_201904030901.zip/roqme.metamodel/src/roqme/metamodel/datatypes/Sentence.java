/**
 */
package roqme.metamodel.datatypes;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sentence</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roqme.metamodel.datatypes.DatatypesPackage#getSentence()
 * @model abstract="true"
 * @generated
 */
public interface Sentence extends DocumentableElement {
} // Sentence
