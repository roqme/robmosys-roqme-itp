Added manually in the generated implementation:

In typeTypeImpl.java

protected TimeTypeImpl() {
	super();
	this.unit = "seconds"; // Needs to be added manually
}