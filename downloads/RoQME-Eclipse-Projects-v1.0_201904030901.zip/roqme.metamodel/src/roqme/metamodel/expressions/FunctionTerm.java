/**
 */
package roqme.metamodel.expressions;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Function Term</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roqme.metamodel.expressions.ExpressionsPackage#getFunctionTerm()
 * @model abstract="true"
 * @generated
 */
public interface FunctionTerm extends NaryTermOp {
} // FunctionTerm
