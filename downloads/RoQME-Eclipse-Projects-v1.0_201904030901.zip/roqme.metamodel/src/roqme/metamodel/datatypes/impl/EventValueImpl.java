/**
 */
package roqme.metamodel.datatypes.impl;

import org.eclipse.emf.ecore.EClass;

import roqme.metamodel.datatypes.DatatypesPackage;
import roqme.metamodel.datatypes.EventValue;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Event Value</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class EventValueImpl extends SingleValueImpl implements EventValue {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EventValueImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return DatatypesPackage.Literals.EVENT_VALUE;
	}

} //EventValueImpl
