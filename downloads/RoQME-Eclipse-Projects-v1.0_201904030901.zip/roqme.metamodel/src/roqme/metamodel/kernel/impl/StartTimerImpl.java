/**
 */
package roqme.metamodel.kernel.impl;

import org.eclipse.emf.ecore.EClass;

import roqme.metamodel.kernel.KernelPackage;
import roqme.metamodel.kernel.StartTimer;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Start Timer</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class StartTimerImpl extends TimerActionImpl implements StartTimer {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected StartTimerImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return KernelPackage.Literals.START_TIMER;
	}

} //StartTimerImpl
