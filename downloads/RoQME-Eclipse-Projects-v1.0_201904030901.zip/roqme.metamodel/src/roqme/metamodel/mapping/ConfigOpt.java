/**
 */
package roqme.metamodel.mapping;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Config Opt</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roqme.metamodel.mapping.MappingPackage#getConfigOpt()
 * @model abstract="true"
 * @generated
 */
public interface ConfigOpt extends EObject {
} // ConfigOpt
