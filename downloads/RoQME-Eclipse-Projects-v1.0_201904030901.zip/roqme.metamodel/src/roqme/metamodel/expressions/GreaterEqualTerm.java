/**
 */
package roqme.metamodel.expressions;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Greater Equal Term</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roqme.metamodel.expressions.ExpressionsPackage#getGreaterEqualTerm()
 * @model
 * @generated
 */
public interface GreaterEqualTerm extends BinaryRelationalOp {
} // GreaterEqualTerm
