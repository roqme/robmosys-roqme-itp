/**
 */
package roqme.metamodel.expressions.impl;

import org.eclipse.emf.ecore.EClass;

import roqme.metamodel.expressions.ExpressionsPackage;
import roqme.metamodel.expressions.SubTerm;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Sub Term</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SubTermImpl extends BinaryArithOpImpl implements SubTerm {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SubTermImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ExpressionsPackage.Literals.SUB_TERM;
	}

} //SubTermImpl
