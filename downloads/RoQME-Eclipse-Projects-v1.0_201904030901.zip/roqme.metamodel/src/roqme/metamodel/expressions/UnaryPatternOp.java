/**
 */
package roqme.metamodel.expressions;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Unary Pattern Op</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roqme.metamodel.expressions.ExpressionsPackage#getUnaryPatternOp()
 * @model abstract="true"
 * @generated
 */
public interface UnaryPatternOp extends UnaryTermOp {
} // UnaryPatternOp
