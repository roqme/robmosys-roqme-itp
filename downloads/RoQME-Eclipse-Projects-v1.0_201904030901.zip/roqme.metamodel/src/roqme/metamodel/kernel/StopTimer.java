/**
 */
package roqme.metamodel.kernel;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Stop Timer</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roqme.metamodel.kernel.KernelPackage#getStopTimer()
 * @model
 * @generated
 */
public interface StopTimer extends TimerAction {
} // StopTimer
