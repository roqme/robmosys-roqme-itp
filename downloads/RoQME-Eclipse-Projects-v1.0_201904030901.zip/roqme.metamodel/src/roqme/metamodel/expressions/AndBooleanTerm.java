/**
 */
package roqme.metamodel.expressions;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>And Boolean Term</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roqme.metamodel.expressions.ExpressionsPackage#getAndBooleanTerm()
 * @model
 * @generated
 */
public interface AndBooleanTerm extends BinaryLogicalOp {
} // AndBooleanTerm
